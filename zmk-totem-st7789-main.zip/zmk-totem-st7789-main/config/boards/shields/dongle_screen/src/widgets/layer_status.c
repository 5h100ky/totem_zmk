/*
 * Copyright (c) 2020 The ZMK Contributors
 *
 * SPDX-License-Identifier: MIT
 */

#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>
LOG_MODULE_DECLARE(zmk, CONFIG_ZMK_LOG_LEVEL);

#include <zmk/display.h>
#include "layer_status.h"
#include <zmk/events/layer_state_changed.h>
#include <zmk/event_manager.h>
#include <zmk/endpoints.h>
#include <zmk/keymap.h>

static sys_slist_t widgets = SYS_SLIST_STATIC_INIT(&widgets);

/* Container dimensions */
#define LAYER_WIDGET_WIDTH  200
#define LAYER_WIDGET_HEIGHT 60

/* Animation duration in ms */
#define LAYER_ANIM_DURATION_MS 300

/* 8-colour palette cycling through layers (RGB hex).
 * Palette wraps at index % 8, so layers 0,8,16,… share a colour. */
static const uint32_t layer_palette[8] = {
    0xFFFFFF, /* White   */
    0x00FFFF, /* Cyan    */
    0xFFFF00, /* Yellow  */
    0xFF8000, /* Orange  */
    0x00FF00, /* Green   */
    0xFF00FF, /* Magenta */
    0x0000FF, /* Blue    */
    0xFF4080, /* Pink    */
};

struct layer_status_state
{
    uint8_t index;
    const char *label;
};

/* LVGL animation callback: moves an object along the Y axis */
static void anim_y_cb(void *obj, int32_t y)
{
    lv_obj_set_y((lv_obj_t *)obj, y);
}

/* Write the layer name (or numeric index) into a label.
 *   - numeric: up to 3 digits for uint8_t (0-255) → 4 bytes needed, 7 gives headroom
 *   - named:   ZMK layer names are typically ≤12 chars; buffer size matches */
static void set_label_text(lv_obj_t *label, struct layer_status_state state)
{
    if (state.label == NULL)
    {
        char text[7] = {};  /* 3 digits + sign + null + padding */
        sprintf(text, "%i", state.index);
        lv_label_set_text(label, text);
    }
    else
    {
        char text[13] = {};  /* 12 chars max + null terminator */
        snprintf(text, sizeof(text), "%s", state.label);
        lv_label_set_text(label, text);
    }
}

/* Create and style a single double-buffer label inside the container.
 * Returns the created object, or NULL on allocation failure (logged). */
static lv_obj_t *make_label(lv_obj_t *parent)
{
    lv_obj_t *label = lv_label_create(parent);
    if (label == NULL)
    {
        LOG_ERR("layer_status: failed to allocate label");
        return NULL;
    }
    lv_obj_set_style_text_font(label, &lv_font_montserrat_40, 0);
    lv_obj_set_style_text_color(label, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_width(label, LAYER_WIDGET_WIDTH);
    lv_obj_set_style_text_align(label, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_y(label, -LAYER_WIDGET_HEIGHT);  /* start off-screen */
    return label;
}

static void layer_status_update_cb(struct layer_status_state state)
{
    struct zmk_widget_layer_status *widget;
    SYS_SLIST_FOR_EACH_CONTAINER(&widgets, widget, node)
    {
        if (widget->label_a == NULL || widget->label_b == NULL)
        {
            continue;  /* allocation failed at init time; skip */
        }

        /* active   = the label currently visible on screen
         * incoming = the label that will slide into view */
        lv_obj_t *active   = widget->label_a_active ? widget->label_a : widget->label_b;
        lv_obj_t *incoming = widget->label_a_active ? widget->label_b : widget->label_a;

        /* Prepare the incoming label */
        set_label_text(incoming, state);
        lv_obj_set_style_text_color(incoming,
                                    lv_color_hex(layer_palette[state.index % 8]),
                                    LV_PART_MAIN);

        if (!widget->initialized)
        {
            /* First render: no animation, place incoming label directly in view */
            lv_obj_set_y(incoming, 0);
            lv_obj_set_y(active, -LAYER_WIDGET_HEIGHT); /* park idle label off-screen */
            widget->initialized = true;
        }
        else
        {
            /* Determine slide direction from signed difference.
             * Both values are cast to int16_t before subtracting so that a uint8_t
             * wrap-around (e.g. 255→0) gives a negative delta (downward slide),
             * and 0→255 gives a positive delta (upward slide). */
            int16_t delta   = (int16_t)state.index - (int16_t)widget->prev_index;
            int32_t out_y   = (delta > 0) ? -LAYER_WIDGET_HEIGHT : LAYER_WIDGET_HEIGHT;
            int32_t in_from = (delta > 0) ?  LAYER_WIDGET_HEIGHT : -LAYER_WIDGET_HEIGHT;

            /* Place the incoming label off-screen, ready to slide in */
            lv_obj_set_y(incoming, in_from);

            /* Slide the active label out */
            lv_anim_t a_out;
            lv_anim_init(&a_out);
            lv_anim_set_var(&a_out, active);
            lv_anim_set_exec_cb(&a_out, anim_y_cb);
            lv_anim_set_time(&a_out, LAYER_ANIM_DURATION_MS);
            lv_anim_set_path_cb(&a_out, lv_anim_path_ease_in_out);
            lv_anim_set_values(&a_out, 0, out_y);
            lv_anim_start(&a_out);

            /* Slide the incoming label in */
            lv_anim_t a_in;
            lv_anim_init(&a_in);
            lv_anim_set_var(&a_in, incoming);
            lv_anim_set_exec_cb(&a_in, anim_y_cb);
            lv_anim_set_time(&a_in, LAYER_ANIM_DURATION_MS);
            lv_anim_set_path_cb(&a_in, lv_anim_path_ease_in_out);
            lv_anim_set_values(&a_in, in_from, 0);
            lv_anim_start(&a_in);
        }

        /* Swap which label is considered active */
        widget->label_a_active = !widget->label_a_active;
        widget->prev_index     = state.index;
    }
}

static struct layer_status_state layer_status_get_state(const zmk_event_t *eh)
{
    uint8_t index = zmk_keymap_highest_layer_active();
    return (struct layer_status_state){
        .index = index,
        .label = zmk_keymap_layer_name(index)};
}

ZMK_DISPLAY_WIDGET_LISTENER(widget_layer_status, struct layer_status_state, layer_status_update_cb,
                            layer_status_get_state)

ZMK_SUBSCRIPTION(widget_layer_status, zmk_layer_state_changed);

int zmk_widget_layer_status_init(struct zmk_widget_layer_status *widget, lv_obj_t *parent)
{
    /* Clipping container: clips the two buffered labels so only the visible
     * portion (within the 200×60 area) is drawn. */
    widget->obj = lv_obj_create(parent);
    lv_obj_set_size(widget->obj, LAYER_WIDGET_WIDTH, LAYER_WIDGET_HEIGHT);
    lv_obj_set_style_bg_opa(widget->obj, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(widget->obj, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(widget->obj, 0, LV_PART_MAIN);
    lv_obj_clear_flag(widget->obj, LV_OBJ_FLAG_SCROLLABLE);

    widget->label_a = make_label(widget->obj);
    widget->label_b = make_label(widget->obj);

    widget->label_a_active = false;
    widget->prev_index     = 0;
    widget->initialized    = false;

    sys_slist_append(&widgets, &widget->node);

    widget_layer_status_init();
    return 0;
}

lv_obj_t *zmk_widget_layer_status_obj(struct zmk_widget_layer_status *widget)
{
    return widget->obj;
}
