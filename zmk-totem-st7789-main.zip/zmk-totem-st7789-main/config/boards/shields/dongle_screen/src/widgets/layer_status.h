/*
 * Copyright (c) 2020 The ZMK Contributors
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include <lvgl.h>
#include <zephyr/kernel.h>

struct zmk_widget_layer_status {
    sys_snode_t node;
    lv_obj_t *obj;        /* clipping container (200×60, overflow hidden) */
    lv_obj_t *label_a;    /* double-buffered label A */
    lv_obj_t *label_b;    /* double-buffered label B */
    bool label_a_active;  /* which label is currently on-screen */
    uint8_t prev_index;   /* layer index shown in the last render */
    bool initialized;     /* false until the first render (skip animation) */
};

int zmk_widget_layer_status_init(struct zmk_widget_layer_status *widget, lv_obj_t *parent);
lv_obj_t *zmk_widget_layer_status_obj(struct zmk_widget_layer_status *widget);
