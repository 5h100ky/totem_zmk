/*
 * Copyright (c) 2024 The ZMK Contributors
 *
 * SPDX-License-Identifier: MIT
 */

/*
 * Datetime status widget for the dongle display.
 *
 * Displays the current date and time in two lines:
 *   YYYY/MM/DD
 *   HH:MM:SS
 *
 * Time is computed as: compile-time build timestamp + elapsed uptime.
 * This provides a reasonable clock without requiring an RTC or network sync.
 * The clock resets to the build timestamp on every reboot.
 */

#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>
#include <lvgl.h>
#include <stdio.h>
#include <string.h>

#include "datetime_status.h"

LOG_MODULE_DECLARE(zmk, CONFIG_ZMK_LOG_LEVEL);

/* -----------------------------------------------------------------------
 * Compile-time build date/time parsing
 *
 * __DATE__ = "Mmm DD YYYY"  e.g. "Mar 13 2026"
 * __TIME__ = "HH:MM:SS"     e.g. "14:25:30"
 * ----------------------------------------------------------------------- */

static const char *MONTH_NAMES = "JanFebMarAprMayJunJulAugSepOctNovDec";

static int build_month(void)
{
    char mon[4] = {__DATE__[0], __DATE__[1], __DATE__[2], '\0'};
    const char *p = strstr(MONTH_NAMES, mon);
    return p ? (int)(p - MONTH_NAMES) / 3 + 1 : 1;
}

static int build_day(void)
{
    /* __DATE__[4] is ' ' for single-digit days (e.g. " 3") or a digit for two-digit days */
    return (__DATE__[4] == ' ')
        ? (__DATE__[5] - '0')
        : ((__DATE__[4] - '0') * 10 + (__DATE__[5] - '0'));
}

static int build_year(void)
{
    return ((__DATE__[7] - '0') * 1000 +
            (__DATE__[8] - '0') * 100  +
            (__DATE__[9] - '0') * 10   +
            (__DATE__[10] - '0'));
}

static int build_hour(void)
{
    return (__TIME__[0] - '0') * 10 + (__TIME__[1] - '0');
}

static int build_min(void)
{
    return (__TIME__[3] - '0') * 10 + (__TIME__[4] - '0');
}

static int build_sec(void)
{
    return (__TIME__[6] - '0') * 10 + (__TIME__[7] - '0');
}

/* -----------------------------------------------------------------------
 * Calendar arithmetic helpers
 * ----------------------------------------------------------------------- */

static bool is_leap(int year)
{
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

static const int DAYS_IN_MONTH[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

/* Compute seconds since Unix epoch (1970-01-01 00:00:00 UTC) for the build timestamp */
static int64_t build_epoch_secs(void)
{
    int year  = build_year();
    int month = build_month();
    int day   = build_day();
    int hour  = build_hour();
    int min   = build_min();
    int sec   = build_sec();

    int64_t days = 0;

    for (int y = 1970; y < year; y++) {
        days += is_leap(y) ? 366 : 365;
    }
    for (int m = 1; m < month; m++) {
        days += DAYS_IN_MONTH[m];
        if (m == 2 && is_leap(year)) {
            days++;
        }
    }
    days += day - 1;

    return days * 86400LL
        + (int64_t)hour * 3600LL
        + (int64_t)min  * 60LL
        + (int64_t)sec;
}

/* Convert Unix epoch seconds → calendar date and time fields */
static void epoch_to_datetime(int64_t secs,
                              int *year, int *month, int *day,
                              int *hour, int *min,   int *sec)
{
    int64_t day_num = secs / 86400LL;
    int64_t rem     = secs % 86400LL;

    if (rem < 0) {
        rem += 86400;
        day_num--;
    }

    *hour = (int)(rem / 3600);
    *min  = (int)((rem % 3600) / 60);
    *sec  = (int)(rem % 60);

    int y = 1970;

    while (y < 3000) {
        int diy = is_leap(y) ? 366 : 365;
        if (day_num < diy) {
            break;
        }
        day_num -= diy;
        y++;
    }
    *year = y;

    int m = 1;

    while (m <= 12) {
        int dim = DAYS_IN_MONTH[m];
        if (m == 2 && is_leap(y)) {
            dim++;
        }
        if (day_num < dim) {
            break;
        }
        day_num -= dim;
        m++;
    }
    *month = m;
    *day   = (int)day_num + 1;
}

/* -----------------------------------------------------------------------
 * Widget state
 * ----------------------------------------------------------------------- */

static sys_slist_t widgets = SYS_SLIST_STATIC_INIT(&widgets);
static int64_t     ref_epoch_secs; /* build timestamp recorded at first init */
static struct k_timer datetime_timer;

static void update_all_widgets(void)
{
    /* Current time = build timestamp + seconds elapsed since boot */
    int64_t now = ref_epoch_secs + (int64_t)(k_uptime_get() / 1000);

    int year, month, day, hour, min, sec;

    epoch_to_datetime(now, &year, &month, &day, &hour, &min, &sec);

    char date_str[12];
    char time_str[10];

    snprintf(date_str, sizeof(date_str), "%04d/%02d/%02d", year, month, day);
    snprintf(time_str, sizeof(time_str), "%02d:%02d:%02d", hour, min, sec);

    struct zmk_widget_datetime_status *widget;

    SYS_SLIST_FOR_EACH_CONTAINER(&widgets, widget, node) {
        lv_label_set_text(widget->date_label, date_str);
        lv_label_set_text(widget->time_label, time_str);
    }
}

static void datetime_timer_cb(struct k_timer *timer)
{
    ARG_UNUSED(timer);
    update_all_widgets();
}

/* -----------------------------------------------------------------------
 * Public API
 * ----------------------------------------------------------------------- */

int zmk_widget_datetime_status_init(struct zmk_widget_datetime_status *widget, lv_obj_t *parent)
{
    /* Record reference epoch and start timer only on first widget init */
    if (sys_slist_is_empty(&widgets)) {
        ref_epoch_secs = build_epoch_secs();
        k_timer_init(&datetime_timer, datetime_timer_cb, NULL);
        k_timer_start(&datetime_timer, K_SECONDS(1), K_SECONDS(1));
    }

    /* Container — wide enough for "YYYY/MM/DD" and "HH:MM:SS" at default font size */
    widget->obj = lv_obj_create(parent);
    lv_obj_set_size(widget->obj, 130, 46);
    lv_obj_set_style_bg_opa(widget->obj, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(widget->obj, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(widget->obj, 0, LV_PART_MAIN);
    lv_obj_clear_flag(widget->obj, LV_OBJ_FLAG_SCROLLABLE);

    /* Date label: YYYY/MM/DD */
    widget->date_label = lv_label_create(widget->obj);
    lv_obj_set_style_text_color(widget->date_label, lv_color_white(), 0);
    lv_obj_align(widget->date_label, LV_ALIGN_TOP_MID, 0, 0);

    /* Time label: HH:MM:SS */
    widget->time_label = lv_label_create(widget->obj);
    lv_obj_set_style_text_color(widget->time_label, lv_color_white(), 0);
    lv_obj_align(widget->time_label, LV_ALIGN_BOTTOM_MID, 0, 0);

    sys_slist_append(&widgets, &widget->node);

    /* Populate with the current date and time immediately */
    update_all_widgets();

    return 0;
}

lv_obj_t *zmk_widget_datetime_status_obj(struct zmk_widget_datetime_status *widget)
{
    return widget->obj;
}
