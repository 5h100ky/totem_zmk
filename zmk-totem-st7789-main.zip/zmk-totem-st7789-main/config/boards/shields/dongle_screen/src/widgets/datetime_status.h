/*
 * Copyright (c) 2024 The ZMK Contributors
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include <lvgl.h>
#include <zephyr/sys/slist.h>

struct zmk_widget_datetime_status {
    sys_snode_t node;
    lv_obj_t *obj;
    lv_obj_t *date_label;
    lv_obj_t *time_label;
};

int zmk_widget_datetime_status_init(struct zmk_widget_datetime_status *widget, lv_obj_t *parent);
lv_obj_t *zmk_widget_datetime_status_obj(struct zmk_widget_datetime_status *widget);
